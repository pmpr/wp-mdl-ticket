<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             680106b08a3ee             |
    |_______________________________________|
*/
 use Pmpr\Module\Ticket\Ticket; Ticket::symcgieuakksimmu();
