<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6720b70c10ff0             |
    |_______________________________________|
*/
 use Pmpr\Module\Ticket\Ticket; Ticket::symcgieuakksimmu();
