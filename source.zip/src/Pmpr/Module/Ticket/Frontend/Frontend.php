<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae8ac620f2             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Ticket\Frontend; use Pmpr\Module\Ticket\Ticket; class Frontend extends Common { public function mameiwsayuyquoeq() { Form::symcgieuakksimmu(); if (!$this->caokeucsksukesyo()->owicscwgeuqcqaig()->mcgoysmkqsqooceq()) { goto umgaesggesswoaqe; } Ajax::symcgieuakksimmu(); umgaesggesswoaqe: } public function wigskegsqequoeks() { $this->waqewsckuayqguos(Ticket::uuqoeigueqguouek . "\x72\145\x6e\x64\145\162\x5f\x66\x72\x6f\156\x74\x65\156\x64\x5f\x63\x6f\156\x76\x65\162\x73\x61\x74\x69\x6f\x6e", [$this, "\155\153\145\145\x6f\163\151\x69\155\x67\x6f\x79\x69\141\171\x6f"]); } public function mkeeosiimgoyiayo($igqsaukqcqscimok) { echo $this->umqeyekmoagusaiq($igqsaukqcqscimok); } }
