<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ecceda761             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Ticket\Frontend; use Pmpr\Module\Ticket\Ticket; class Frontend extends Common { public function mameiwsayuyquoeq() { Form::symcgieuakksimmu(); if (!$this->caokeucsksukesyo()->owicscwgeuqcqaig()->mcgoysmkqsqooceq()) { goto umgaesggesswoaqe; } Ajax::symcgieuakksimmu(); umgaesggesswoaqe: } public function wigskegsqequoeks() { $this->waqewsckuayqguos(Ticket::uuqoeigueqguouek . "\162\145\x6e\x64\145\x72\x5f\x66\162\157\x6e\x74\145\x6e\x64\137\x63\x6f\x6e\166\x65\162\x73\141\164\151\157\156", [$this, "\155\x6b\145\145\157\163\151\x69\x6d\147\157\171\x69\x61\171\157"]); } public function mkeeosiimgoyiayo($igqsaukqcqscimok) { echo $this->umqeyekmoagusaiq($igqsaukqcqscimok); } }
