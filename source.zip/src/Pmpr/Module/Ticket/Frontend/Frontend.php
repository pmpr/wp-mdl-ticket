<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f43aadda0db             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Ticket\Frontend; use Pmpr\Module\Ticket\Ticket; class Frontend extends Common { public function mameiwsayuyquoeq() { Form::symcgieuakksimmu(); if (!$this->caokeucsksukesyo()->owicscwgeuqcqaig()->mcgoysmkqsqooceq()) { goto uqqaiagaeqgqgaiy; } Ajax::symcgieuakksimmu(); uqqaiagaeqgqgaiy: } public function wigskegsqequoeks() { $this->waqewsckuayqguos(Ticket::uuqoeigueqguouek . "\x72\x65\156\x64\x65\x72\137\146\162\x6f\156\x74\x65\156\144\x5f\143\157\x6e\166\145\x72\x73\x61\x74\x69\157\156", [$this, "\155\153\x65\145\157\x73\151\151\x6d\x67\157\x79\151\141\171\x6f"]); } public function mkeeosiimgoyiayo($igqsaukqcqscimok) { echo $this->umqeyekmoagusaiq($igqsaukqcqscimok); } }
