<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646a8dfc4e3f             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Ticket\Frontend; class Frontend extends Common { public function mameiwsayuyquoeq() { Form::symcgieuakksimmu(); if (!$this->caokeucsksukesyo()->owicscwgeuqcqaig()->mcgoysmkqsqooceq()) { goto kciouyuaqkyqomam; } Ajax::symcgieuakksimmu(); kciouyuaqkyqomam: } public function wigskegsqequoeks() { $this->waqewsckuayqguos(self::uuqoeigueqguouek . "\x72\x65\x6e\144\x65\162\137\x66\x72\x6f\x6e\164\145\x6e\x64\x5f\143\157\156\x76\145\162\x73\x61\x74\x69\157\x6e", [$this, "\155\x6b\x65\x65\157\x73\151\151\x6d\x67\157\171\151\141\x79\x6f"]); } public function mkeeosiimgoyiayo($igqsaukqcqscimok) { echo $this->umqeyekmoagusaiq($igqsaukqcqscimok); } }
