<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6606b20223daf             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Ticket\Frontend; class Frontend extends Common { public function mameiwsayuyquoeq() { Form::symcgieuakksimmu(); if (!$this->caokeucsksukesyo()->owicscwgeuqcqaig()->mcgoysmkqsqooceq()) { goto acaqummmoyiemqss; } Ajax::symcgieuakksimmu(); acaqummmoyiemqss: } public function wigskegsqequoeks() { $this->waqewsckuayqguos(self::uuqoeigueqguouek . "\162\145\156\144\145\x72\137\x66\x72\x6f\x6e\x74\x65\x6e\x64\137\143\x6f\x6e\x76\x65\162\x73\141\164\x69\x6f\x6e", [$this, "\155\153\145\x65\157\x73\x69\x69\155\x67\x6f\171\x69\141\171\157"]); } public function mkeeosiimgoyiayo($igqsaukqcqscimok) { echo $this->umqeyekmoagusaiq($igqsaukqcqscimok); } }
