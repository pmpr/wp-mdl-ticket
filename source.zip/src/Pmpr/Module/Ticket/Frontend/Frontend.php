<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6687085b8bd11             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Ticket\Frontend; class Frontend extends Common { public function mameiwsayuyquoeq() { Form::symcgieuakksimmu(); if (!$this->caokeucsksukesyo()->owicscwgeuqcqaig()->mcgoysmkqsqooceq()) { goto ickcmqoiosquugwe; } Ajax::symcgieuakksimmu(); ickcmqoiosquugwe: } public function wigskegsqequoeks() { $this->waqewsckuayqguos(self::uuqoeigueqguouek . "\x72\145\x6e\x64\x65\x72\x5f\x66\x72\x6f\156\x74\145\156\144\137\x63\x6f\x6e\166\145\x72\x73\141\164\151\157\x6e", [$this, "\x6d\x6b\x65\145\157\x73\151\151\x6d\147\x6f\171\x69\x61\x79\157"]); } public function mkeeosiimgoyiayo($igqsaukqcqscimok) { echo $this->umqeyekmoagusaiq($igqsaukqcqscimok); } }
