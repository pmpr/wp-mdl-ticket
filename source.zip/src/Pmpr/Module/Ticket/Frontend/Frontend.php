<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             660dc24d41ccd             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Ticket\Frontend; class Frontend extends Common { public function mameiwsayuyquoeq() { Form::symcgieuakksimmu(); if (!$this->caokeucsksukesyo()->owicscwgeuqcqaig()->mcgoysmkqsqooceq()) { goto acaqummmoyiemqss; } Ajax::symcgieuakksimmu(); acaqummmoyiemqss: } public function wigskegsqequoeks() { $this->waqewsckuayqguos(self::uuqoeigueqguouek . "\x72\x65\x6e\144\145\x72\137\146\x72\157\156\164\145\156\x64\137\143\157\x6e\166\145\x72\163\141\164\151\157\156", [$this, "\x6d\153\x65\145\157\x73\151\151\x6d\x67\x6f\x79\151\141\171\157"]); } public function mkeeosiimgoyiayo($igqsaukqcqscimok) { echo $this->umqeyekmoagusaiq($igqsaukqcqscimok); } }
