<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce11e4813aa             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Ticket\Frontend; use Pmpr\Module\Ticket\Ticket; class Frontend extends Common { public function mameiwsayuyquoeq() { Form::symcgieuakksimmu(); if (!$this->caokeucsksukesyo()->owicscwgeuqcqaig()->mcgoysmkqsqooceq()) { goto cecuyayqoioasumi; } Ajax::symcgieuakksimmu(); cecuyayqoioasumi: } public function wigskegsqequoeks() { $this->waqewsckuayqguos(Ticket::uuqoeigueqguouek . "\162\145\156\x64\145\162\137\146\162\157\x6e\x74\145\x6e\x64\137\x63\157\x6e\x76\145\162\163\x61\x74\x69\x6f\x6e", [$this, "\x6d\x6b\145\145\x6f\x73\x69\x69\155\147\157\171\x69\141\171\157"]); } public function mkeeosiimgoyiayo($igqsaukqcqscimok) { echo $this->umqeyekmoagusaiq($igqsaukqcqscimok); } }
