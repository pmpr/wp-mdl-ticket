<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cb570e0b6ec             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Ticket\Frontend; class Frontend extends Common { public function mameiwsayuyquoeq() { Form::symcgieuakksimmu(); if (!$this->caokeucsksukesyo()->owicscwgeuqcqaig()->mcgoysmkqsqooceq()) { goto cecuyayqoioasumi; } Ajax::symcgieuakksimmu(); cecuyayqoioasumi: } public function wigskegsqequoeks() { $this->waqewsckuayqguos(self::uuqoeigueqguouek . "\x72\145\156\x64\145\x72\x5f\x66\x72\157\x6e\x74\x65\156\x64\x5f\143\x6f\156\166\x65\x72\163\x61\x74\151\157\x6e", [$this, "\x6d\153\x65\x65\157\163\151\x69\x6d\147\x6f\171\x69\141\x79\x6f"]); } public function mkeeosiimgoyiayo($igqsaukqcqscimok) { echo $this->umqeyekmoagusaiq($igqsaukqcqscimok); } }
