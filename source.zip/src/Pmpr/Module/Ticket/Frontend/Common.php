<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f43aadda0db             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Ticket\Frontend; use Pmpr\Module\Ticket\Container; abstract class Common extends Container { public function umqeyekmoagusaiq($igqsaukqcqscimok) : string { return $this->iuygowkemiiwqmiw("\143\x6f\x6e\x76\x65\162\x73\141\164\151\157\x6e\x2f\x69\164\145\x6d", (array) $igqsaukqcqscimok); } }
