<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646a8dfc4e3f             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Ticket\Frontend; use Pmpr\Module\Ticket\Container; abstract class Common extends Container { public function umqeyekmoagusaiq($igqsaukqcqscimok) : string { return $this->iuygowkemiiwqmiw("\143\x6f\x6e\166\x65\162\163\141\164\x69\157\156\57\x69\164\145\x6d", (array) $igqsaukqcqscimok); } }
