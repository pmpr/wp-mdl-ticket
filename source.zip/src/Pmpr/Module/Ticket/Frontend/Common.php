<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             678aa11316422             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Ticket\Frontend; use Pmpr\Module\Ticket\Container; abstract class Common extends Container { public function umqeyekmoagusaiq($igqsaukqcqscimok) : string { return $this->iuygowkemiiwqmiw("\x63\157\x6e\166\145\162\163\x61\x74\151\x6f\x6e\x2f\x69\x74\x65\155", (array) $igqsaukqcqscimok); } }
