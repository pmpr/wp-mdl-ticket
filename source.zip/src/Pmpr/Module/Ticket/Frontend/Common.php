<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4b8003cc0             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Ticket\Frontend; use Pmpr\Module\Ticket\Container; abstract class Common extends Container { public function umqeyekmoagusaiq($igqsaukqcqscimok) : string { return $this->iuygowkemiiwqmiw("\x63\x6f\x6e\166\x65\162\x73\x61\x74\151\157\x6e\x2f\151\x74\x65\x6d", (array) $igqsaukqcqscimok); } }
