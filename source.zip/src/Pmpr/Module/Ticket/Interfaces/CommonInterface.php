<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6684012921441             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Ticket\Interfaces; interface CommonInterface { const skgwuociausakiqe = "\x74\162\x61\143\153"; const yeaekcacwwyyqigq = "\164\151\x63\x6b\x65\164"; const sgsawoooocqwouiy = "\164\x72\141\143\153\x69\156\147\x5f\143\157\144\x65"; const uuqoeigueqguouek = self::yeaekcacwwyyqigq . "\x5f"; const iccgkcckiwosagso = self::uuqoeigueqguouek . "\x6e\157\x6e\143\145"; const ksieewmgckgeqiuy = self::iccgkcckiwosagso . "\x61\x63\164\151\157\x6e"; const asywgyemkouimocw = self::uuqoeigueqguouek . "\x69\144"; const cmiegiycgiucucgs = "\162\145\161\x75\145\x73\164\x5f\x69\144"; const miwkyequoaigisoa = "\162\x65\163\x70\157\x6e\x73\x65\x5f\151\x64"; }
