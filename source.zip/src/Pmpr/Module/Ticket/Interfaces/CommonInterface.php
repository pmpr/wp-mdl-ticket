<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cb570e0b6ec             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Ticket\Interfaces; interface CommonInterface { const skgwuociausakiqe = "\x74\162\x61\x63\x6b"; const yeaekcacwwyyqigq = "\x74\x69\x63\x6b\145\x74"; const sgsawoooocqwouiy = "\x74\x72\x61\x63\153\151\x6e\x67\x5f\x63\157\x64\x65"; const uuqoeigueqguouek = self::yeaekcacwwyyqigq . "\x5f"; const iccgkcckiwosagso = self::uuqoeigueqguouek . "\156\157\156\143\145"; const ksieewmgckgeqiuy = self::iccgkcckiwosagso . "\x61\x63\x74\x69\x6f\156"; const asywgyemkouimocw = self::uuqoeigueqguouek . "\151\144"; const cmiegiycgiucucgs = "\x72\x65\161\x75\145\x73\x74\137\151\x64"; const miwkyequoaigisoa = "\x72\145\x73\x70\x6f\x6e\163\x65\x5f\151\x64"; }
