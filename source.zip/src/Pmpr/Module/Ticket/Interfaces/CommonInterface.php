<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             660dc24d41ccd             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Ticket\Interfaces; interface CommonInterface { const skgwuociausakiqe = "\x74\x72\141\x63\153"; const yeaekcacwwyyqigq = "\164\151\143\153\x65\x74"; const sgsawoooocqwouiy = "\164\x72\x61\143\153\x69\x6e\x67\137\143\x6f\x64\x65"; const uuqoeigueqguouek = self::yeaekcacwwyyqigq . "\137"; const iccgkcckiwosagso = self::uuqoeigueqguouek . "\156\x6f\156\143\145"; const ksieewmgckgeqiuy = self::iccgkcckiwosagso . "\141\x63\x74\x69\x6f\x6e"; const asywgyemkouimocw = self::uuqoeigueqguouek . "\x69\x64"; const cmiegiycgiucucgs = "\162\145\x71\165\x65\x73\x74\137\x69\x64"; const miwkyequoaigisoa = "\x72\145\x73\160\157\156\163\x65\137\x69\144"; }
