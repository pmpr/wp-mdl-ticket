<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6606b20223daf             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Ticket\Interfaces; interface CommonInterface { const skgwuociausakiqe = "\x74\x72\141\x63\x6b"; const yeaekcacwwyyqigq = "\x74\x69\x63\153\145\164"; const sgsawoooocqwouiy = "\164\x72\x61\x63\x6b\x69\156\x67\137\143\x6f\144\x65"; const uuqoeigueqguouek = self::yeaekcacwwyyqigq . "\x5f"; const iccgkcckiwosagso = self::uuqoeigueqguouek . "\156\x6f\156\x63\x65"; const ksieewmgckgeqiuy = self::iccgkcckiwosagso . "\x61\x63\x74\x69\157\156"; const asywgyemkouimocw = self::uuqoeigueqguouek . "\151\144"; const cmiegiycgiucucgs = "\x72\145\161\x75\x65\x73\x74\137\151\144"; const miwkyequoaigisoa = "\x72\145\163\x70\157\x6e\163\145\x5f\x69\x64"; }
