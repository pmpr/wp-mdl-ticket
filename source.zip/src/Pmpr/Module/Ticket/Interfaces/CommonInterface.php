<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6687085b8bd11             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Ticket\Interfaces; interface CommonInterface { const skgwuociausakiqe = "\164\162\x61\x63\x6b"; const yeaekcacwwyyqigq = "\x74\x69\x63\x6b\x65\x74"; const sgsawoooocqwouiy = "\164\x72\141\143\153\x69\156\147\x5f\143\x6f\x64\145"; const uuqoeigueqguouek = self::yeaekcacwwyyqigq . "\137"; const iccgkcckiwosagso = self::uuqoeigueqguouek . "\156\x6f\x6e\143\x65"; const ksieewmgckgeqiuy = self::iccgkcckiwosagso . "\141\143\x74\x69\157\156"; const asywgyemkouimocw = self::uuqoeigueqguouek . "\151\144"; const cmiegiycgiucucgs = "\x72\x65\161\x75\145\163\164\x5f\x69\144"; const miwkyequoaigisoa = "\162\x65\163\160\x6f\156\163\145\x5f\151\144"; }
