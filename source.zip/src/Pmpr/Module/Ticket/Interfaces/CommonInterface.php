<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646a8dfc4e3f             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Ticket\Interfaces; interface CommonInterface { const skgwuociausakiqe = "\164\162\141\x63\x6b"; const yeaekcacwwyyqigq = "\x74\x69\x63\153\x65\x74"; const sgsawoooocqwouiy = "\164\162\141\143\153\151\x6e\147\x5f\x63\157\x64\x65"; const uuqoeigueqguouek = self::yeaekcacwwyyqigq . "\137"; const iccgkcckiwosagso = self::uuqoeigueqguouek . "\156\x6f\x6e\143\x65"; const ksieewmgckgeqiuy = self::iccgkcckiwosagso . "\141\x63\164\151\x6f\x6e"; const asywgyemkouimocw = self::uuqoeigueqguouek . "\x69\144"; const cmiegiycgiucucgs = "\x72\145\161\165\x65\x73\x74\x5f\151\144"; const miwkyequoaigisoa = "\x72\x65\163\160\157\x6e\163\145\x5f\151\144"; }
