<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cb570e0b6ec             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Ticket\Model; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Response extends AbstractResponse { const kyyqoeaeyqeeicwo = self::agowqguqsycqyymy . self::mswocgcucqoaesaa; const ggcqemwekmeikkiu = "\x65\x6c\x65\x63\x74\x65\x64\137" . self::imqkacyywmmamsqm . self::mswocgcucqoaesaa; public function ckgmycmaukqgkosk() { $this->oyeskqayoscwciem()->yioesawwewqaigow(IconInterface::osaqwqwkkmocawgs)->guiaswksukmgageq(__("\122\145\x73\160\157\156\163\145", PR__MDL__TICKET))->muuwuqssqkaieqge(__("\122\x65\163\x70\x6f\x6e\x73\x65\163", PR__MDL__TICKET))->wkesqcmiekqoykag()->aseucqksocwomwos()->qemeyueyiwgsokuc(); parent::ckgmycmaukqgkosk(); } public function ewaqwooqoqmcoomi() { parent::ewaqwooqoqmcoomi(); $this->cquokmemekqqywgi($this->eoaomaokwkwqyqiq(self::kyyqoeaeyqeeicwo)->gswweykyogmsyawy(__("\x52\x65\163\160\157\x6e\x64\163", PR__MDL__TICKET))->ckgquisaimmgwuyu(Respond::class))->cquokmemekqqywgi($this->eoaomaokwkwqyqiq(self::ggcqemwekmeikkiu)->gswweykyogmsyawy(__("\x45\x6c\145\x63\164\145\x64\x20\122\145\163\x70\157\156\163\145", PR__MDL__TICKET))->geimymogiqyssawi(ElectedResponse::class)->kkeymosoimmgsaug()); } }
