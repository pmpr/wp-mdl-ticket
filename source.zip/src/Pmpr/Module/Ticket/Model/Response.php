<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6687085b8bd11             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Ticket\Model; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Response extends AbstractResponse { const kyyqoeaeyqeeicwo = self::agowqguqsycqyymy . self::mswocgcucqoaesaa; const ggcqemwekmeikkiu = "\145\154\145\143\x74\x65\144\x5f" . self::imqkacyywmmamsqm . self::mswocgcucqoaesaa; public function ckgmycmaukqgkosk() { $this->oyeskqayoscwciem()->yioesawwewqaigow(IconInterface::osaqwqwkkmocawgs)->guiaswksukmgageq(__("\122\x65\163\160\157\x6e\x73\x65", PR__MDL__TICKET))->muuwuqssqkaieqge(__("\122\x65\163\160\x6f\156\163\x65\163", PR__MDL__TICKET))->wkesqcmiekqoykag()->aseucqksocwomwos()->qemeyueyiwgsokuc(); parent::ckgmycmaukqgkosk(); } public function ewaqwooqoqmcoomi() { parent::ewaqwooqoqmcoomi(); $this->cquokmemekqqywgi($this->eoaomaokwkwqyqiq(self::kyyqoeaeyqeeicwo)->gswweykyogmsyawy(__("\122\x65\163\x70\x6f\x6e\x64\163", PR__MDL__TICKET))->ckgquisaimmgwuyu(Respond::class))->cquokmemekqqywgi($this->eoaomaokwkwqyqiq(self::ggcqemwekmeikkiu)->gswweykyogmsyawy(__("\105\154\145\143\x74\x65\144\x20\x52\x65\x73\160\x6f\156\163\145", PR__MDL__TICKET))->geimymogiqyssawi(ElectedResponse::class)->kkeymosoimmgsaug()); } }
