<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646a8dfc4e3f             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Ticket\Model; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Response extends AbstractResponse { const kyyqoeaeyqeeicwo = self::agowqguqsycqyymy . self::mswocgcucqoaesaa; const ggcqemwekmeikkiu = "\x65\x6c\x65\x63\164\x65\x64\137" . self::imqkacyywmmamsqm . self::mswocgcucqoaesaa; public function ckgmycmaukqgkosk() { $this->oyeskqayoscwciem()->yioesawwewqaigow(IconInterface::osaqwqwkkmocawgs)->guiaswksukmgageq(__("\x52\145\163\x70\x6f\x6e\x73\x65", PR__MDL__TICKET))->muuwuqssqkaieqge(__("\122\145\163\160\x6f\156\x73\x65\x73", PR__MDL__TICKET))->wkesqcmiekqoykag()->aseucqksocwomwos()->qemeyueyiwgsokuc(); parent::ckgmycmaukqgkosk(); } public function ewaqwooqoqmcoomi() { parent::ewaqwooqoqmcoomi(); $this->cquokmemekqqywgi($this->eoaomaokwkwqyqiq(self::kyyqoeaeyqeeicwo)->gswweykyogmsyawy(__("\x52\x65\163\x70\157\x6e\x64\163", PR__MDL__TICKET))->ckgquisaimmgwuyu(Respond::class))->cquokmemekqqywgi($this->eoaomaokwkwqyqiq(self::ggcqemwekmeikkiu)->gswweykyogmsyawy(__("\x45\x6c\x65\143\x74\x65\x64\40\122\145\163\x70\157\x6e\x73\145", PR__MDL__TICKET))->geimymogiqyssawi(ElectedResponse::class)->kkeymosoimmgsaug()); } }
