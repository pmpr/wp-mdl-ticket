<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6606b20223daf             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Ticket\Model; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Response extends AbstractResponse { const kyyqoeaeyqeeicwo = self::agowqguqsycqyymy . self::mswocgcucqoaesaa; const ggcqemwekmeikkiu = "\x65\x6c\145\143\164\145\144\137" . self::imqkacyywmmamsqm . self::mswocgcucqoaesaa; public function ckgmycmaukqgkosk() { $this->oyeskqayoscwciem()->yioesawwewqaigow(IconInterface::osaqwqwkkmocawgs)->guiaswksukmgageq(__("\x52\145\x73\x70\x6f\156\163\145", PR__MDL__TICKET))->muuwuqssqkaieqge(__("\x52\145\x73\x70\x6f\x6e\163\145\163", PR__MDL__TICKET))->wkesqcmiekqoykag()->aseucqksocwomwos()->qemeyueyiwgsokuc(); parent::ckgmycmaukqgkosk(); } public function ewaqwooqoqmcoomi() { parent::ewaqwooqoqmcoomi(); $this->cquokmemekqqywgi($this->eoaomaokwkwqyqiq(self::kyyqoeaeyqeeicwo)->gswweykyogmsyawy(__("\x52\145\163\160\x6f\x6e\144\163", PR__MDL__TICKET))->ckgquisaimmgwuyu(Respond::class))->cquokmemekqqywgi($this->eoaomaokwkwqyqiq(self::ggcqemwekmeikkiu)->gswweykyogmsyawy(__("\105\x6c\x65\x63\164\x65\144\40\122\x65\x73\x70\x6f\156\x73\145", PR__MDL__TICKET))->geimymogiqyssawi(ElectedResponse::class)->kkeymosoimmgsaug()); } }
