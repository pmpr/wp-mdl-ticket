<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6687085b8bd11             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Ticket\Model; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Respond extends Common { public $timestamps = [self::CREATED_AT]; public function ckgmycmaukqgkosk() { parent::ckgmycmaukqgkosk(); $this->oyeskqayoscwciem()->yioesawwewqaigow(IconInterface::osaqwqwkkmocawgs)->guiaswksukmgageq(__("\x52\x65\163\x70\x6f\x6e\x64", PR__MDL__TICKET))->muuwuqssqkaieqge(__("\122\x65\x73\x70\x6f\x6e\144\x73", PR__MDL__TICKET)); } public function ewaqwooqoqmcoomi() { $this->cquokmemekqqywgi($this->qoemykoeuecmsmwe(self::ckmsuwamgymouaeu)->acceqyqygswoecwe(8)->gswweykyogmsyawy(__("\x52\145\163\160\157\x6e\144\x65\162", PR__MDL__TICKET)))->cquokmemekqqywgi($this->eoaomaokwkwqyqiq(self::asywgyemkouimocw)->gswweykyogmsyawy(__("\124\151\x63\153\x65\x74", PR__MDL__TICKET))->wuuqgaekqeymecag(Ticket::class)->eewuieiqoqmekwmw(self::sayycgcceusuyycg))->cquokmemekqqywgi($this->eoaomaokwkwqyqiq(self::miwkyequoaigisoa)->gswweykyogmsyawy(__("\122\x65\x73\x70\x6f\156\x73\x65", PR__MDL__TICKET))->wuuqgaekqeymecag(Response::class)); parent::ewaqwooqoqmcoomi(); } }
