<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae8ac620f2             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Ticket\Model; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Respond extends Common { public $timestamps = [self::CREATED_AT]; public function ckgmycmaukqgkosk() { parent::ckgmycmaukqgkosk(); $this->oyeskqayoscwciem()->yioesawwewqaigow(IconInterface::osaqwqwkkmocawgs)->guiaswksukmgageq(__("\122\x65\163\160\157\x6e\x64", PR__MDL__TICKET))->muuwuqssqkaieqge(__("\122\145\x73\160\x6f\156\x64\163", PR__MDL__TICKET)); } public function ewaqwooqoqmcoomi() { $this->cquokmemekqqywgi($this->qoemykoeuecmsmwe(Constants::ckmsuwamgymouaeu)->acceqyqygswoecwe(8)->gswweykyogmsyawy(__("\122\x65\163\x70\157\x6e\144\x65\162", PR__MDL__TICKET)))->cquokmemekqqywgi($this->eoaomaokwkwqyqiq(self::asywgyemkouimocw)->gswweykyogmsyawy(__("\124\151\143\153\x65\x74", PR__MDL__TICKET))->wuuqgaekqeymecag(Ticket::class)->eewuieiqoqmekwmw(Constants::sayycgcceusuyycg))->cquokmemekqqywgi($this->eoaomaokwkwqyqiq(Ticket::miwkyequoaigisoa)->gswweykyogmsyawy(__("\122\x65\163\160\x6f\156\x73\145", PR__MDL__TICKET))->wuuqgaekqeymecag(Response::class)); parent::ewaqwooqoqmcoomi(); } }
