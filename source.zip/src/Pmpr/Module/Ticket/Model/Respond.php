<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6684012921441             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Ticket\Model; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Respond extends Common { public $timestamps = [self::CREATED_AT]; public function ckgmycmaukqgkosk() { parent::ckgmycmaukqgkosk(); $this->oyeskqayoscwciem()->yioesawwewqaigow(IconInterface::osaqwqwkkmocawgs)->guiaswksukmgageq(__("\x52\145\x73\160\157\x6e\x64", PR__MDL__TICKET))->muuwuqssqkaieqge(__("\x52\145\x73\160\x6f\x6e\x64\x73", PR__MDL__TICKET)); } public function ewaqwooqoqmcoomi() { $this->cquokmemekqqywgi($this->qoemykoeuecmsmwe(self::ckmsuwamgymouaeu)->acceqyqygswoecwe(8)->gswweykyogmsyawy(__("\122\145\x73\160\x6f\156\144\x65\162", PR__MDL__TICKET)))->cquokmemekqqywgi($this->eoaomaokwkwqyqiq(self::asywgyemkouimocw)->gswweykyogmsyawy(__("\x54\x69\143\153\x65\x74", PR__MDL__TICKET))->wuuqgaekqeymecag(Ticket::class)->eewuieiqoqmekwmw(self::sayycgcceusuyycg))->cquokmemekqqywgi($this->eoaomaokwkwqyqiq(self::miwkyequoaigisoa)->gswweykyogmsyawy(__("\x52\x65\x73\160\x6f\x6e\163\145", PR__MDL__TICKET))->wuuqgaekqeymecag(Response::class)); parent::ewaqwooqoqmcoomi(); } }
