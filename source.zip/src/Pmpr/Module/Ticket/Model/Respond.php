<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cb570e0b6ec             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Ticket\Model; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Respond extends Common { public $timestamps = [self::CREATED_AT]; public function ckgmycmaukqgkosk() { parent::ckgmycmaukqgkosk(); $this->oyeskqayoscwciem()->yioesawwewqaigow(IconInterface::osaqwqwkkmocawgs)->guiaswksukmgageq(__("\x52\145\x73\160\157\156\144", PR__MDL__TICKET))->muuwuqssqkaieqge(__("\x52\145\x73\160\157\156\x64\163", PR__MDL__TICKET)); } public function ewaqwooqoqmcoomi() { $this->cquokmemekqqywgi($this->qoemykoeuecmsmwe(self::ckmsuwamgymouaeu)->acceqyqygswoecwe(8)->gswweykyogmsyawy(__("\x52\145\x73\x70\x6f\156\144\145\162", PR__MDL__TICKET)))->cquokmemekqqywgi($this->eoaomaokwkwqyqiq(self::asywgyemkouimocw)->gswweykyogmsyawy(__("\x54\x69\x63\153\145\164", PR__MDL__TICKET))->wuuqgaekqeymecag(Ticket::class)->eewuieiqoqmekwmw(self::sayycgcceusuyycg))->cquokmemekqqywgi($this->eoaomaokwkwqyqiq(self::miwkyequoaigisoa)->gswweykyogmsyawy(__("\122\145\x73\x70\157\156\163\145", PR__MDL__TICKET))->wuuqgaekqeymecag(Response::class)); parent::ewaqwooqoqmcoomi(); } }
