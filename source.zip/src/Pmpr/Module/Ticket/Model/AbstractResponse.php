<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cb570e0b6ec             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Ticket\Model; abstract class AbstractResponse extends Common { public $timestamps = [self::CREATED_AT]; public function ckgmycmaukqgkosk() { parent::ckgmycmaukqgkosk(); $this->esoauokkgywesoku([self::cqycgsyykemiygou => __("\x41\164\x74\x61\x63\150\x6d\145\156\164", PR__CMN__FOUNDATION)]); } public function ewaqwooqoqmcoomi() { $this->cquokmemekqqywgi($this->gysoeyaguiyewoes(self::TEXT)->gswweykyogmsyawy(__("\124\145\x78\164", PR__MDL__TICKET))); parent::ewaqwooqoqmcoomi(); } }
