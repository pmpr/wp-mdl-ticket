<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646a8dfc4e3f             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Ticket\Model; abstract class AbstractResponse extends Common { public $timestamps = [self::CREATED_AT]; public function ckgmycmaukqgkosk() { parent::ckgmycmaukqgkosk(); $this->esoauokkgywesoku([self::cqycgsyykemiygou => __("\x41\x74\x74\141\143\x68\x6d\x65\x6e\164", PR__CMN__FOUNDATION)]); } public function ewaqwooqoqmcoomi() { $this->cquokmemekqqywgi($this->gysoeyaguiyewoes(self::TEXT)->gswweykyogmsyawy(__("\124\145\x78\164", PR__MDL__TICKET))); parent::ewaqwooqoqmcoomi(); } }
