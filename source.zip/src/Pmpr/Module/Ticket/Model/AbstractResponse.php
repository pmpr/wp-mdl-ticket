<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce11e4813aa             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Ticket\Model; use Pmpr\Common\Foundation\Interfaces\Constants; abstract class AbstractResponse extends Common { public $timestamps = [self::CREATED_AT]; public function ckgmycmaukqgkosk() { parent::ckgmycmaukqgkosk(); $this->esoauokkgywesoku([Constants::cqycgsyykemiygou => __("\101\164\164\141\x63\x68\155\x65\156\164", PR__CMN__FOUNDATION)]); } public function ewaqwooqoqmcoomi() { $this->cquokmemekqqywgi($this->gysoeyaguiyewoes(Constants::TEXT)->gswweykyogmsyawy(__("\x54\145\x78\164", PR__MDL__TICKET))); parent::ewaqwooqoqmcoomi(); } }
