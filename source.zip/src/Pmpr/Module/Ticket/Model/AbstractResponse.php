<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6687085b8bd11             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Ticket\Model; abstract class AbstractResponse extends Common { public $timestamps = [self::CREATED_AT]; public function ckgmycmaukqgkosk() { parent::ckgmycmaukqgkosk(); $this->esoauokkgywesoku([self::cqycgsyykemiygou => __("\x41\x74\x74\141\x63\x68\x6d\x65\156\164", PR__CMN__FOUNDATION)]); } public function ewaqwooqoqmcoomi() { $this->cquokmemekqqywgi($this->gysoeyaguiyewoes(self::TEXT)->gswweykyogmsyawy(__("\124\145\x78\x74", PR__MDL__TICKET))); parent::ewaqwooqoqmcoomi(); } }
