<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             680106b08a3ee             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Ticket\Model; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\ORM\Model; abstract class AbstractResponse extends Model { const asywgyemkouimocw = Constants::yeaekcacwwyyqigq . Constants::mswocgcucqoaesaa; public function register() { $this->esoauokkgywesoku(Constants::cqycgsyykemiygou, __('Attachment', PR__CMN__FOUNDATION)); } public function uwmqacgewuauagai() { $eqwoegegiamegqsm = $this->caokeucsksukesyo()->skckwsgymkimyuwo(); $this->cquokmemekqqywgi($eqwoegegiamegqsm->gysoeyaguiyewoes(Constants::TEXT)->gswweykyogmsyawy(__('Text', PR__MDL__TICKET)))->cquokmemekqqywgi($eqwoegegiamegqsm->qwwuoqeeiyuoyogs(Constants::CREATED_AT)->gswweykyogmsyawy(__('Created At', PR__MDL__TICKET))->qcqeqimisiisswky()); parent::uwmqacgewuauagai(); } }
