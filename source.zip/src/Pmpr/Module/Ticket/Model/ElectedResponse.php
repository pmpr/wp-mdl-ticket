<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6606b20223daf             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Ticket\Model; use Pmpr\Common\Foundation\Interfaces\IconInterface; class ElectedResponse extends Common { const miwkyequoaigisoa = self::imqkacyywmmamsqm . self::mswocgcucqoaesaa; public $timestamps = false; public function ckgmycmaukqgkosk() { parent::ckgmycmaukqgkosk(); $this->oyeskqayoscwciem()->yioesawwewqaigow(IconInterface::osaqwqwkkmocawgs)->guiaswksukmgageq(__("\105\x6c\x65\x63\164\x65\x64\40\x52\145\x73\x70\157\x6e\x73\145", PR__MDL__TICKET))->muuwuqssqkaieqge(__("\105\154\145\143\x74\x65\144\40\122\145\163\160\x6f\x6e\x73\145\x73", PR__MDL__TICKET))->gemkqqguesukeocw()->aseucqksocwomwos()->wkesqcmiekqoykag()->qemeyueyiwgsokuc(); } public function ewaqwooqoqmcoomi() { $this->cquokmemekqqywgi($this->gysoeyaguiyewoes(self::qescuiwgsyuikume)->gswweykyogmsyawy(__("\124\x69\164\x6c\145", PR__MDL__TICKET)))->cquokmemekqqywgi($this->eoaomaokwkwqyqiq(self::miwkyequoaigisoa)->gswweykyogmsyawy(__("\x52\145\x73\160\x6f\156\x73\x65", PR__MDL__TICKET))->geimymogiqyssawi(Response::class)->wakqsiacyacmumuw()); parent::ewaqwooqoqmcoomi(); } }
