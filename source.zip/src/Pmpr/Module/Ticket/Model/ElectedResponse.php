<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646a8dfc4e3f             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Ticket\Model; use Pmpr\Common\Foundation\Interfaces\IconInterface; class ElectedResponse extends Common { const miwkyequoaigisoa = self::imqkacyywmmamsqm . self::mswocgcucqoaesaa; public $timestamps = false; public function ckgmycmaukqgkosk() { parent::ckgmycmaukqgkosk(); $this->oyeskqayoscwciem()->yioesawwewqaigow(IconInterface::osaqwqwkkmocawgs)->guiaswksukmgageq(__("\x45\154\x65\x63\164\x65\x64\x20\122\x65\163\160\157\156\x73\x65", PR__MDL__TICKET))->muuwuqssqkaieqge(__("\x45\154\x65\x63\x74\145\x64\40\x52\x65\x73\160\157\156\x73\x65\x73", PR__MDL__TICKET))->gemkqqguesukeocw()->aseucqksocwomwos()->wkesqcmiekqoykag()->qemeyueyiwgsokuc(); } public function ewaqwooqoqmcoomi() { $this->cquokmemekqqywgi($this->gysoeyaguiyewoes(self::qescuiwgsyuikume)->gswweykyogmsyawy(__("\x54\x69\164\154\145", PR__MDL__TICKET)))->cquokmemekqqywgi($this->eoaomaokwkwqyqiq(self::miwkyequoaigisoa)->gswweykyogmsyawy(__("\x52\145\163\160\x6f\x6e\x73\x65", PR__MDL__TICKET))->geimymogiqyssawi(Response::class)->wakqsiacyacmumuw()); parent::ewaqwooqoqmcoomi(); } }
