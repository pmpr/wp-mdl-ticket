<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cb570e0b6ec             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Ticket\REST; class Response extends Common { public function __construct() { $this->rest_base = self::imqkacyywmmamsqm; parent::__construct(); } }
