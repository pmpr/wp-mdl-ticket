<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6684012921441             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Ticket\REST; class Response extends Common { public function __construct() { $this->rest_base = self::imqkacyywmmamsqm; parent::__construct(); } }
