<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6606b20223daf             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Ticket\REST; class Response extends Common { public function __construct() { $this->rest_base = self::imqkacyywmmamsqm; parent::__construct(); } }
