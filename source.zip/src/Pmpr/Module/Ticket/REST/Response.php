<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6720b70c10ff0             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Ticket\REST; use Pmpr\Common\Foundation\Interfaces\Constants; class Response extends Common { public function __construct() { $this->rest_base = Constants::imqkacyywmmamsqm; parent::__construct(); } }
