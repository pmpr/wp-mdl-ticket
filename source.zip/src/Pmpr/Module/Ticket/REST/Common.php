<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6687085b8bd11             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Ticket\REST; use Pmpr\Common\Foundation\REST\RESTController; abstract class Common extends RESTController { public function __construct() { parent::__construct(); $this->namespace .= "\57\x74\x69\x63\x6b\145\164"; } }
