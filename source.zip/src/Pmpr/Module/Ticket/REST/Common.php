<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646a8dfc4e3f             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Ticket\REST; use Pmpr\Common\Foundation\REST\RESTController; abstract class Common extends RESTController { public function __construct() { parent::__construct(); $this->namespace .= "\57\164\151\x63\153\x65\x74"; } }
