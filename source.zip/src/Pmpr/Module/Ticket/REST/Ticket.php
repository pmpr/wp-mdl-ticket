<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646a8dfc4e3f             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Ticket\REST; use Pmpr\Module\Ticket\Traits\SubmissionTrait; use WP_Error; use WP_HTTP_Response; use WP_REST_Request; use WP_REST_Response; class Ticket extends Common { use SubmissionTrait; public function __construct() { $this->rest_base = "\164\x69\x63\x6b\145\x74"; parent::__construct(); } }
