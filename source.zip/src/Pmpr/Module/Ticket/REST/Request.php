<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6606b20223daf             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Ticket\REST; class Request extends Common { public function __construct() { $this->rest_base = self::qgeesceacsmeqacu; parent::__construct(); } }
