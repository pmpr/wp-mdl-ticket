<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ecceda761             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Ticket\REST; use Pmpr\Common\Foundation\Interfaces\Constants; class Request extends Common { public function __construct() { $this->rest_base = Constants::qgeesceacsmeqacu; parent::__construct(); } }
