<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6687085b8bd11             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Ticket\REST; class Request extends Common { public function __construct() { $this->rest_base = self::qgeesceacsmeqacu; parent::__construct(); } }
