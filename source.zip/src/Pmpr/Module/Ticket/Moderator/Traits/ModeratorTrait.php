<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             660dc24d41ccd             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Ticket\Moderator\Traits; use Pmpr\Module\Ticket\Moderator\Moderator; trait ModeratorTrait { protected ?Moderator $moderator = null; public function xowuwmoiekgcwiaq() : Moderator { if ($this->moderator) { goto kqgcyoscsusgoaqi; } $this->moderator = new Moderator(); kqgcyoscsusgoaqi: return $this->moderator; } }
