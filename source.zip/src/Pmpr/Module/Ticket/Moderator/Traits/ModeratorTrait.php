<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6684012921441             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Ticket\Moderator\Traits; use Pmpr\Module\Ticket\Moderator\Moderator; trait ModeratorTrait { protected ?Moderator $moderator = null; public function xowuwmoiekgcwiaq() : Moderator { if ($this->moderator) { goto egyyiccaeeiooaua; } $this->moderator = new Moderator(); egyyiccaeeiooaua: return $this->moderator; } }
