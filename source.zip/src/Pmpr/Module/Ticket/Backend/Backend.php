<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             660dc24d41ccd             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Ticket\Backend; class Backend extends Common { public function mameiwsayuyquoeq() { $mumyimcwkaemyyue = $this->caokeucsksukesyo()->owicscwgeuqcqaig(); if (!$mumyimcwkaemyyue->mcgoysmkqsqooceq()) { goto cgiscsqwwgqqaeqi; } Ajax::symcgieuakksimmu(); cgiscsqwwgqqaeqi: } public function wigskegsqequoeks() { $this->waqewsckuayqguos(self::uuqoeigueqguouek . "\162\145\156\x64\x65\x72\x5f\x62\141\x63\153\x65\x6e\x64\x5f\x63\157\156\166\145\x72\x73\x61\x74\151\x6f\x6e", [$this, "\x6d\153\145\x65\157\x73\151\151\x6d\x67\x6f\x79\x69\x61\171\x6f"]); } public function mkeeosiimgoyiayo($igqsaukqcqscimok) { echo $this->umqeyekmoagusaiq($igqsaukqcqscimok); } }
