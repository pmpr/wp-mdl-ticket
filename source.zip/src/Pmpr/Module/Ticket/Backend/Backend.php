<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6606b20223daf             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Ticket\Backend; class Backend extends Common { public function mameiwsayuyquoeq() { $mumyimcwkaemyyue = $this->caokeucsksukesyo()->owicscwgeuqcqaig(); if (!$mumyimcwkaemyyue->mcgoysmkqsqooceq()) { goto cgiscsqwwgqqaeqi; } Ajax::symcgieuakksimmu(); cgiscsqwwgqqaeqi: } public function wigskegsqequoeks() { $this->waqewsckuayqguos(self::uuqoeigueqguouek . "\162\145\156\x64\145\x72\x5f\x62\141\143\x6b\x65\x6e\x64\x5f\x63\x6f\x6e\x76\145\162\163\141\164\x69\x6f\x6e", [$this, "\x6d\153\145\x65\x6f\163\x69\x69\155\x67\157\x79\x69\141\171\x6f"]); } public function mkeeosiimgoyiayo($igqsaukqcqscimok) { echo $this->umqeyekmoagusaiq($igqsaukqcqscimok); } }
