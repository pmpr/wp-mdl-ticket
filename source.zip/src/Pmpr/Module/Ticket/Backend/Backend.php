<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6684012921441             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Ticket\Backend; class Backend extends Common { public function mameiwsayuyquoeq() { $mumyimcwkaemyyue = $this->caokeucsksukesyo()->owicscwgeuqcqaig(); if (!$mumyimcwkaemyyue->mcgoysmkqsqooceq()) { goto cecuyayqoioasumi; } Ajax::symcgieuakksimmu(); cecuyayqoioasumi: } public function wigskegsqequoeks() { $this->waqewsckuayqguos(self::uuqoeigueqguouek . "\162\145\156\x64\145\162\137\142\141\x63\153\145\156\x64\137\x63\157\156\x76\145\x72\x73\x61\x74\x69\157\156", [$this, "\155\x6b\145\145\x6f\163\x69\151\155\147\157\171\x69\141\x79\157"]); } public function mkeeosiimgoyiayo($igqsaukqcqscimok) { echo $this->umqeyekmoagusaiq($igqsaukqcqscimok); } }
