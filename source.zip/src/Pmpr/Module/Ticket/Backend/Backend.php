<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cb570e0b6ec             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Ticket\Backend; class Backend extends Common { public function mameiwsayuyquoeq() { $mumyimcwkaemyyue = $this->caokeucsksukesyo()->owicscwgeuqcqaig(); if (!$mumyimcwkaemyyue->mcgoysmkqsqooceq()) { goto hoeeyiowekaeemko; } Ajax::symcgieuakksimmu(); hoeeyiowekaeemko: } public function wigskegsqequoeks() { $this->waqewsckuayqguos(self::uuqoeigueqguouek . "\x72\x65\156\144\145\162\x5f\142\141\x63\153\x65\156\x64\137\143\157\x6e\x76\145\162\x73\141\x74\151\x6f\156", [$this, "\155\153\145\145\x6f\163\151\x69\155\x67\x6f\171\x69\x61\171\x6f"]); } public function mkeeosiimgoyiayo($igqsaukqcqscimok) { echo $this->umqeyekmoagusaiq($igqsaukqcqscimok); } }
