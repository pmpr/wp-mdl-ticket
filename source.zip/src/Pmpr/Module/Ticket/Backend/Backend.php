<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f43aadda0db             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Ticket\Backend; use Pmpr\Module\Ticket\Ticket as Initiator; class Backend extends Common { public function mameiwsayuyquoeq() { $mumyimcwkaemyyue = $this->caokeucsksukesyo()->owicscwgeuqcqaig(); if (!$mumyimcwkaemyyue->mcgoysmkqsqooceq()) { goto kecwuwwcwokuksyq; } Ajax::symcgieuakksimmu(); kecwuwwcwokuksyq: } public function wigskegsqequoeks() { $this->waqewsckuayqguos(Initiator::uuqoeigueqguouek . "\162\x65\x6e\x64\145\162\x5f\142\x61\143\153\x65\156\144\x5f\x63\157\x6e\166\145\162\x73\141\x74\x69\x6f\156", [$this, "\155\x6b\145\145\157\163\151\x69\x6d\x67\x6f\x79\151\141\x79\157"]); } public function mkeeosiimgoyiayo($igqsaukqcqscimok) { echo $this->umqeyekmoagusaiq($igqsaukqcqscimok); } }
