<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646a8dfc4e3f             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Ticket\Backend; class Backend extends Common { public function mameiwsayuyquoeq() { $mumyimcwkaemyyue = $this->caokeucsksukesyo()->owicscwgeuqcqaig(); if (!$mumyimcwkaemyyue->mcgoysmkqsqooceq()) { goto qicwaskssogcokgm; } Ajax::symcgieuakksimmu(); qicwaskssogcokgm: } public function wigskegsqequoeks() { $this->waqewsckuayqguos(self::uuqoeigueqguouek . "\162\x65\156\x64\x65\x72\x5f\x62\141\x63\x6b\x65\156\144\x5f\143\x6f\x6e\x76\145\162\x73\141\164\151\x6f\x6e", [$this, "\x6d\153\x65\145\x6f\x73\151\151\x6d\147\x6f\171\151\x61\171\x6f"]); } public function mkeeosiimgoyiayo($igqsaukqcqscimok) { echo $this->umqeyekmoagusaiq($igqsaukqcqscimok); } }
