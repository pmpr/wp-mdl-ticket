<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ecceda761             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Ticket\Backend; use Pmpr\Module\Ticket\Ticket as Initiator; class Backend extends Common { public function mameiwsayuyquoeq() { $mumyimcwkaemyyue = $this->caokeucsksukesyo()->owicscwgeuqcqaig(); if (!$mumyimcwkaemyyue->mcgoysmkqsqooceq()) { goto ickcmqoiosquugwe; } Ajax::symcgieuakksimmu(); ickcmqoiosquugwe: } public function wigskegsqequoeks() { $this->waqewsckuayqguos(Initiator::uuqoeigueqguouek . "\162\145\156\x64\x65\162\137\x62\x61\143\153\x65\x6e\144\x5f\x63\x6f\x6e\166\x65\x72\x73\141\x74\x69\x6f\156", [$this, "\155\153\145\145\157\163\x69\151\155\147\157\x79\x69\141\171\157"]); } public function mkeeosiimgoyiayo($igqsaukqcqscimok) { echo $this->umqeyekmoagusaiq($igqsaukqcqscimok); } }
