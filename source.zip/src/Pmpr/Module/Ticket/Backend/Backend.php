<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fc5bd45f44             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Ticket\Backend; use Pmpr\Module\Ticket\Ticket as Initiator; class Backend extends Common { public function mameiwsayuyquoeq() { if ($this->caokeucsksukesyo()->owicscwgeuqcqaig()->mcgoysmkqsqooceq(Ajax::wiysygukkaksueso)) { Ajax::symcgieuakksimmu(); } } public function wigskegsqequoeks() { $this->waqewsckuayqguos(Initiator::uuqoeigueqguouek . "\x72\x65\156\144\145\162\x5f\142\x61\143\153\145\x6e\144\x5f\x63\x6f\156\166\x65\x72\x73\141\164\151\x6f\x6e", [$this, "\x6d\153\x65\x65\157\x73\151\151\155\x67\x6f\171\x69\141\171\157"]); } public function mkeeosiimgoyiayo($igqsaukqcqscimok) { echo $this->umqeyekmoagusaiq($igqsaukqcqscimok); } }
