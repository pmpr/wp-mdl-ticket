<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             660dc24d41ccd             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Ticket\Panel; use Pmpr\Module\Panel\REST\AbstractREST; class Controller extends AbstractREST { }
